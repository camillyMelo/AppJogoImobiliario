package com.example.superbancoimobiliario.model;

public class CreditCard {
    private int id;
    private double balance;
    private static int last_Card_Id = 0;


    public CreditCard(){
        this.id = last_Card_Id + 1;
        this.balance = 15000;
        last_Card_Id++;
    }

    public void creditValue(double valor) {
        balance += valor;
    }

    public void debitValue(double valor) throws Exception {
        if (valor > balance) {
            throw new Exception("Saldo indisponível");
        } else {
             balance -= valor;
        }

    }
    public static int getLast_Card_Id() {
        return last_Card_Id;
    }

    public static void setLast_Card_Id(int last_Card_Id) {
        CreditCard.last_Card_Id = last_Card_Id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}

package com.example.superbancoimobiliario.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.superbancoimobiliario.R;
import com.example.superbancoimobiliario.model.CreditCard;
import com.example.superbancoimobiliario.model.StarBank;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private EditText inputEditTextCartaoMais;
    private EditText inputEditTextCartaoMenos;
    private EditText inputEditTextValor;
    private Button receberButton;
    private Button pagarButton;
    private Button transfenciaButton;
    private Button resetButton;
    private Button rodadaButton;

    StarBank starBank = new StarBank();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // StarBank.getInstance().startCreditCards();
        starBank.startCreditCards();

        inputEditTextCartaoMais = findViewById(R.id.edittext_input_cartao_mais);
        inputEditTextCartaoMenos = findViewById(R.id.edittext_input_cartao_menos);
        inputEditTextValor = findViewById(R.id.edittext_input_valor);

        receberButton = findViewById(R.id.button_receber);
        receberButton.setOnClickListener(this);
        pagarButton = findViewById(R.id.button_pagar);
        pagarButton.setOnClickListener(this);
        transfenciaButton = findViewById(R.id.button_transferencia);
        transfenciaButton.setOnClickListener(this);
        resetButton = findViewById(R.id.button_reset);
        resetButton.setOnClickListener(this);
        rodadaButton = findViewById(R.id.button_rodada);
        rodadaButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_receber:
                receive();
                break;

            case R.id.button_pagar:
                try {
                    pay();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                break;
            case R.id.button_transferencia:
                transfer();
                break;
            case R.id.button_rodada:
                rodada();
                break;
            case R.id.button_reset:
                starBank.startCreditCards();
                break;
        }
    }


    private void receive() {

        int idMais;
        double valor;


        String cartaoMais = inputEditTextCartaoMais.getText().toString();
        String valorInserido = inputEditTextValor.getText().toString();

        if(cartaoMais == null || valorInserido == null){
            Toast.makeText(this, getString(R.string.campos_não_preenchidos_receive), Toast.LENGTH_SHORT).show();
            return;
        }

        idMais = Integer.parseInt(cartaoMais);
        valor = Double.parseDouble(valorInserido);


        if (idMais<7 && idMais>0){
            CreditCard card = starBank.getCreditCard(idMais);
            starBank.receive(card, valor);

            String balance = String.valueOf(starBank.getCreditCard(idMais).getBalance());
            Toast.makeText(this, "Saldo do cartão "+ idMais+": " + balance, Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, getString(R.string.id_invalido), Toast.LENGTH_SHORT).show();
        }

    }
    private void pay() throws Exception {
        int idMenos;
        double valor;

        String cartaoMenos = inputEditTextCartaoMenos.getText().toString();
        String valorInserido = inputEditTextValor.getText().toString();

        if(cartaoMenos == "" || valorInserido == ""){
            Toast.makeText(this, getString(R.string.campos_não_preenchidos_pay), Toast.LENGTH_SHORT).show();
            return;
        }

        idMenos = Integer.parseInt(cartaoMenos);
        valor = Double.parseDouble(valorInserido);

        if (idMenos<7 && idMenos>0){
            try {
                starBank.pay(starBank.getCreditCard(idMenos), valor);
            } catch (Exception e) {
                Toast.makeText(this, getString(R.string.valor_invalido), Toast.LENGTH_SHORT).show();
            }
            String balance = String.valueOf(starBank.getCreditCard(idMenos).getBalance());
            Toast.makeText(this, "Saldo do cartão "+ idMenos+": " + balance, Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, getString(R.string.id_invalido), Toast.LENGTH_SHORT).show();
        }

    }
    private void transfer() {
        int idMais, idMenos;
        double valor;

        String cartaoMais = inputEditTextCartaoMais.getText().toString();
        String cartaoMenos = inputEditTextCartaoMenos.getText().toString();
        String valorInserido = inputEditTextValor.getText().toString();

        if(cartaoMais == "" || cartaoMenos == "" || valorInserido == "" ){
            Toast.makeText(this, getString(R.string.campos_não_preenchidos), Toast.LENGTH_SHORT).show();
            return;
        }

        idMais = Integer.parseInt(cartaoMais);
        idMenos = Integer.parseInt(cartaoMenos);
        valor = Double.parseDouble(valorInserido);

        if(idMais<7 && idMais>0 && idMenos>0 && idMenos<7){
            if (starBank.transfer(starBank.getCreditCard(idMais), starBank.getCreditCard(idMenos), valor)){

                String balanceMais = String.valueOf(starBank.getCreditCard(idMais).getBalance());
                String balanceMenos= String.valueOf(starBank.getCreditCard(idMenos).getBalance());

                Toast.makeText(this, "Saldo do cartão "+ idMais+": " + balanceMais + "  " + "Saldo do cartão "+ idMais+": " + balanceMenos, Toast.LENGTH_SHORT).show();
            } else{
                Toast.makeText(this, getString(R.string.valor_invalido), Toast.LENGTH_SHORT).show();
            }
        } else{
            Toast.makeText(this, getString(R.string.id_invalido), Toast.LENGTH_SHORT).show();
        }
    }


    private void rodada() {
        int idMais;
        double valor;

        String cartaoMais = inputEditTextCartaoMais.getText().toString();
        String valorInserido = inputEditTextValor.getText().toString();

        if(cartaoMais == "" || valorInserido == ""){
            Toast.makeText(this, getString(R.string.campos_não_preenchidos_receive), Toast.LENGTH_SHORT).show();
            return;
        }

        idMais = Integer.parseInt(cartaoMais);
        valor = Double.parseDouble(valorInserido);

        if (idMais<7 && idMais>0){
            starBank.roundCompleted(starBank.getCreditCard(idMais), valor);

            String balance = String.valueOf(starBank.getCreditCard(idMais).getBalance());
            Toast.makeText(this, "Saldo do cartão "+ idMais+": " + balance, Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this, getString(R.string.id_invalido), Toast.LENGTH_SHORT).show();
        }

    }

}
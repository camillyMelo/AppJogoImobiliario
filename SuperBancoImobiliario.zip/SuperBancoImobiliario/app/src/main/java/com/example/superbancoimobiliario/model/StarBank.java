package com.example.superbancoimobiliario.model;

import java.util.ArrayList;

public class StarBank {
    private static StarBank instance = null;

    private ArrayList<CreditCard> cards;

    public StarBank(){
        cards = new ArrayList<>();
    };

    //deu erro
   // public static StarBank getInstance(){
       // if (instance == null){
         //   instance = new StarBank();
      //  }
      //  return instance;
  //  }

    public void startCreditCards(){
        for (int i = 1; i<7; i++) {
            cards.remove(i);
        }
        for (int i = 1; i<7; i++){
            cards.add(new CreditCard());
        }
    }

    public void roundCompleted(CreditCard c, double valor){
        c.creditValue(valor);
    }


    public boolean transfer(CreditCard cCredit, CreditCard cDebit, double valor) {
        try {
            cDebit.debitValue(valor);
        } catch (Exception e) {
            return false;
        }
        cCredit.creditValue(valor);
        return true;
    }

    public void receive(CreditCard c, double valor){
        c.creditValue(valor);
    }

    public void pay(CreditCard c, double valor) throws Exception {
        c.debitValue(valor);
    }

    public CreditCard getCreditCard(int id){
        CreditCard c = cards.get(id);
        return c;
    }

}
